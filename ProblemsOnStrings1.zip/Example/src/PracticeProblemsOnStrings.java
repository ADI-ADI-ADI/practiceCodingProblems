import java.util.HashSet;
import java.util.*;

public class PracticeProblemsOnStrings {

    /*

    // check if strings are anagram or not

    public static boolean isAnagramOrNot(String word, String anagram) {

        if (word.length() != anagram.length()) {
            return false;
        }

        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            int index = anagram.indexOf(c);

            if (index != -1) {
                anagram = anagram.substring(0, index) + anagram.substring(index + 1, anagram.length());
            } else{
                return false;}
        }
        return anagram.isEmpty();
    }

     */
    //--------------------------------------------------------------------------
/*
// check for unique characters using indexOf
    public static boolean uniqueCharacters(String word){
        for (int i = 0; i < word.length(); i++){
            char c = word.charAt(i);
            if (word.indexOf(c)!= word.lastIndexOf(c))
                return false;
        }
            return true;
    }
*/
//------------------------------------------------------------------------
    /*
    //check for unique characters using hashsets

    public static boolean uniqueCharacters(String word){
        HashSet cS = new HashSet();
        for (int i =0; i< word.length(); i++){
            char c = word.charAt(i);
         if (!cS.add(c))
             return false;
        }
        return true;
    }
*/
    //-------------------------------------------------------------------------------
    /*
    // to print duplicates character in a string
    public static void countDuplicateCharacters(String str)
    {

        Map<Character, Integer> map = new HashMap<Character, Integer>();

        char[] charArray = str.toCharArray();

        for (char c : charArray) {

            if (map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            }
            else {
                map.put(c, 1);
            }
        }

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {

            if (entry.getValue() > 1) {
                System.out.println(entry.getKey() + " : " + entry.getValue());
            }
        }
    }

*/

    //-------------------------------------------------------------------------
    /*
    //program to find the first non-repeated array
    public static Character firstNonRepeated(String str){
        char [] charArray = str.toCharArray();
        for (int i =0; i<str.length(); i++){
            if (str.lastIndexOf(charArray[i])==str.indexOf(charArray[i])){
                return charArray[i];
            }

        }
        return null;
    }

*/



    public static void main(String [] args){

        /*
        // reverse a string using string buffer
      String name = "ATTACK ON TITAN";

      StringBuffer sb = new StringBuffer(name);

        System.out.println("Reverse string is " + sb.reverse());

         */

 //---------------------------------------------------------------------------
    /*

    // reverse string using for loop

        String name = "Aditya Amrit";
        String reverse = "";

        for  (int i = name.length()-1; i>=0; --i){
            reverse = reverse + name.charAt(i);
        }
        System.out.println("The reversed string is " + reverse);

     */
//-------------------------------------------------------------------
        /*
        // anagram or not
        String word = "earth";
        String anagram = "heart";

        System.out.println("The words are anagrams? : " + isAnagramOrNot(word, anagram));
        */

/*
//----------------------------------------------------------------------------
        // check for unique characters in a string using indexOf() method

        System.out.println("the given string 'APPLE' has all unique characters? " + " :" + uniqueCharacters("Apple"));
        System.out.println("the given string 'CAR' has all unique characters? " + ": " + uniqueCharacters("car"));
        System.out.println("the given string 'MOZART' has all unique characters? " + ": " + uniqueCharacters("mozart"));
*/
        //-----------------------------------------------------------------
        /*
        //check for unique strings using hashsets
        System.out.println("the given string 'APPLE' has all unique characters? " + " :" + uniqueCharacters("Apple"));
        System.out.println("the given string 'CAR' has all unique characters? " + ": " + uniqueCharacters("car"));
        System.out.println("the given string 'MOZART' has all unique characters? " + ": " + uniqueCharacters("mozart"));
        */
//-------------------------------------------------------------------------------
        /*
        // program to find duplicate characters in a string using hashmap

        String str = "apple pie";
        countDuplicateCharacters(str);
         */
//--------------------------------------------------------------------
        /*
        //program to find first non-repeated array
        System.out.println("the first non repeated character in an array is " + firstNonRepeated("aditya"));
        System.out.println("the first non repeated character in an array is " + firstNonRepeated("mmorpg"));
         */

        //---------------------------------------------------------

        /*
        // count occurences of character in a string

        String name = "aditya amrit";
        char toSearch = 'a';
        int count = 0;

        for (int i =0; i< name.length(); i++){
            if (name.charAt(i)== toSearch) {
                count++;
            }
        }
        System.out.println("the occurences of " + toSearch + "is " +  count);

---------------------------------------------------
         */

        /*
        //find and count occurences of substring in string

        String str = "This is my code. It is written in Java";
        int count = (str.split("is").length)-1;
        System.out.println("The occurrences of given substring is " + count);
         */
//---------------------------------------------------------------
        /*
        //check if strings are palindrome or not
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        String pal = "";

        for (char i : input.toCharArray()){
            pal = i +pal;
        }
        if(pal.equalsIgnoreCase(input)){
            System.out.println("is a palindrome");
        }
        else{
            System.out.println("is not a palindrome");
        }

         */
        //--------------------------------------------------------
    }

}
